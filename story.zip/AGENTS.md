# Repository Guidelines

## Project Structure & Module Organization

This repository is an Obsidian vault for 《伽蓝烬》, a Southern and Northern Dynasties novel set in late Northern Wei Luoyang (528–534). Markdown files at the root are the working documents:

- `构思_故事总纲与人物设定.md`: current premise, chapter summaries, source links, and draft/planning status.
- `构思_人物档案.md`: maintained character profiles, distinguishing current narrative facts, character testimony, future plans, and unresolved details; consult this before changing character continuity.
- Current narrative: `正文_00_序章_铜驼金铎_v3.md`, `正文_01_卷一_河阴血_v3.md`, `正文_02_卷二_白袍客v4.md`, `正文_03_卷三_修罗场.md`, `正文_04_卷四_雷火劫.md`, and `正文_05_卷五_东阳雪劫.md`. Earlier drafts and dated snapshots remain historical versions.
- `夜食_v2.md`: written expansion chapter, not yet integrated into the five volumes; `夜食.md` preserves its earlier draft. `构思_志怪元素与五章扩充方案.md` distinguishes this completed chapter from four unwritten chapters and planned ghost returns.
- `构思_第二版修订方案.md`: second-draft planning and original revision commentary.
- `评估_序章与卷一编辑意见.md` and its `_v2.md` and `_v3.md` counterparts: editorial reviews by draft version.
- `构思_支线设计与主线交织.md`: secondary plotlines and their connections to the main story.
- `素材_历史人物与轶闻典故.md`: narrative adoption status and unverified research candidates, not a guarantee of historical accuracy.
- `构思_门阀背景与情节设计.md`: aristocratic-clan background and related plot design.
- `.obsidian/`: local Obsidian workspace and plugin settings; change only when vault behavior intentionally changes.

Keep notes at the root. Use `构思_主题.md` for planning, `素材_主题.md` for research, `评估_主题.md` for reviews, and `正文_序号_卷次_篇名.md` for drafts. Use two-digit sequence numbers and `_vN` suffixes for revisions (for example, `_v2`, `_v3`); preserve earlier versions and keep planning commentary separate from narrative.

## Build, Test, and Development Commands

There is no build system, package manifest, or automated test suite. Open the directory as an Obsidian vault to edit and preview Markdown. Before sharing changes, inspect the changed files and search for unresolved placeholders:

```powershell
Get-ChildItem -File -Filter '*.md'
rg 'TODO|待定|FIXME' -g '*.md'
```

If Markdown tooling is added later, document its install and validation commands here.

## Writing Style & Naming Conventions

Use UTF-8 Markdown, concise `#`/`##`/`###` headings, and Chinese punctuation consistent with neighboring notes. Preserve the project’s historical-fiction tone and distinguish factual historical material from invented events. Use full-width punctuation in prose, clear section headings, and descriptive filenames; avoid renaming existing files without updating references.

## Testing Guidelines

Validation is editorial rather than automated: preview changed notes in Obsidian, check heading hierarchy, confirm internal links and filenames, and verify that added historical details fit the established setting and chronology. No coverage threshold applies.

## Commit & Pull Request Guidelines

No Git history or remote workflow is currently available, so no established commit convention can be inferred. When version control is introduced, use short imperative summaries (for example, `Refine volume one opening`) and include a brief description of narrative, continuity, or configuration changes. For review, identify edited notes, explain continuity-sensitive changes, and attach screenshots only when layout or Obsidian configuration is relevant.

## Agent-Specific Instructions

Preserve existing Chinese prose and `.obsidian/` settings unless the task explicitly requests changes. When renaming notes, update file references in this guide and Obsidian's workspace. Prefer focused edits and keep story facts consistent across `构思_故事总纲与人物设定.md`, `正文_*.md`, and supporting notes. When authorized narrative revisions change character facts, update the corresponding entries in `构思_人物档案.md`; keep unadopted plans separate and resolve conflicts in favor of the latest narrative.
